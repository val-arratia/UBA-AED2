
template<class T>
T cuadrado(T x) {
    return x * x;
}

//class Cuadrado{
//public:
//    Cuadrado(int x);
//    int cuadrado(int);
//
//private:
//    int _x;
//};
//Cuadrado::Cuadrado(int x) : _x(x) {}
//
//int Cuadrado::cuadrado(int x) {
//    return x * x;
//}
//
//class Contenedor{
//    Contenedor();
//
//};
//
//class Elem{
//
//};