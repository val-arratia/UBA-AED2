//
// Created by clinux01 on 6/4/22.
//

#ifndef SOLUCION_FUNCIONES_H
#define SOLUCION_FUNCIONES_H

bool esBisiesto(Anio anio);

int diasEnMes(int anio, int mes);

#endif //SOLUCION_FUNCIONES_H
